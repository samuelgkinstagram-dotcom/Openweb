const path = require('node:path');
const { execFileSync } = require('node:child_process');

module.exports = async function setOpenWebIcon(context) {
  if (context.electronPlatformName !== 'win32') return;

  const executable = path.join(context.appOutDir, 'OpenWeb.exe');
  const icon = path.join(__dirname, '..', 'assets', 'openweb.ico');
  const rcedit = path.join(__dirname, '..', 'node_modules', 'electron-winstaller', 'vendor', 'rcedit.exe');
  execFileSync(rcedit, [executable, '--set-icon', icon], { stdio: 'inherit' });
};
