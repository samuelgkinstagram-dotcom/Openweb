const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('openwebActivity', {
  getData: () => ipcRenderer.invoke('activity:get-data'),
  openHistory: (url) => ipcRenderer.invoke('activity:open-history', url),
  openDownload: (id) => ipcRenderer.invoke('activity:open-download', id),
  openDownloadsFolder: () => ipcRenderer.invoke('activity:open-downloads-folder'),
  showDownload: (id) => ipcRenderer.invoke('activity:show-download', id),
  cancelDownload: (id) => ipcRenderer.invoke('activity:cancel-download', id),
  clearHistory: () => ipcRenderer.invoke('activity:clear-history'),
  onUpdated: (callback) => ipcRenderer.on('activity:updated', callback),
  onSetKind: (callback) => ipcRenderer.on('activity:set-kind', (_event, kind) => callback(kind))
});
