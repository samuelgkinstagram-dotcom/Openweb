const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('openwebSettings', {
  get: () => ipcRenderer.invoke('settings:get'),
  save: (settings, restartNow) => ipcRenderer.invoke('settings:save', settings, restartNow),
  clearData: () => ipcRenderer.invoke('settings:clear-data'),
  chooseDownloadDirectory: () => ipcRenderer.invoke('settings:choose-download-directory'),
  openDownloadsFolder: () => ipcRenderer.invoke('settings:open-downloads-folder'),
  setDefaultBrowser: () => ipcRenderer.invoke('settings:set-default-browser'),
  onAdBlockStatus: (callback) => ipcRenderer.on('settings:adblock-status', (_event, status) => callback(status)),
  onDownloadProgress: (callback) => ipcRenderer.on('settings:download-progress', (_event, progress) => callback(progress))
});
