const api = window.openweb;
const tabStrip = document.querySelector('#tab-strip');
const address = document.querySelector('#address');
const backButton = document.querySelector('#back');
const forwardButton = document.querySelector('#forward');
let state = { tabs: [], activeTabId: null };

function render(nextState) {
  if (!nextState) return;
  state = nextState;
  tabStrip.querySelectorAll('.tab').forEach((tab) => tab.remove());

  for (const tab of state.tabs) {
    const item = document.createElement('div');
    item.className = `tab${tab.active ? ' active' : ''}`;
    item.setAttribute('role', 'tab');
    item.setAttribute('aria-selected', String(tab.active));
    item.title = tab.url || 'Nova guia';

    const title = document.createElement('button');
    title.className = 'tab-title';
    title.type = 'button';
    title.textContent = tab.loading ? 'Carregando…' : (tab.title || 'Nova guia');
    title.addEventListener('click', () => api.selectTab(tab.id));

    const close = document.createElement('button');
    close.className = 'tab-close';
    close.type = 'button';
    close.textContent = '×';
    close.title = 'Fechar aba';
    close.setAttribute('aria-label', `Fechar ${tab.title || 'aba'}`);
    close.addEventListener('click', (event) => {
      event.stopPropagation();
      api.closeTab(tab.id);
    });

    const favicon = document.createElement('img');
    favicon.className = 'tab-favicon';
    favicon.alt = '';
    favicon.src = tab.favIconUrl || 'assets/openweb-logo.png';
    favicon.onerror = () => {
      favicon.onerror = null;
      favicon.src = 'assets/openweb-logo.png';
    };
    item.append(favicon, title, close);
    tabStrip.insertBefore(item, document.querySelector('#new-tab'));
    if (tab.active) {
      address.value = tab.url || '';
      backButton.disabled = !tab.canGoBack;
      forwardButton.disabled = !tab.canGoForward;
    }
  }
}

document.querySelector('#navigation').addEventListener('submit', (event) => {
  event.preventDefault();
  api.navigate(address.value);
  address.blur();
});

document.querySelector('#back').addEventListener('click', () => api.back());
document.querySelector('#forward').addEventListener('click', () => api.forward());
document.querySelector('#reload').addEventListener('click', () => api.reload());
document.querySelector('#new-tab').addEventListener('click', () => api.newTab());
document.querySelector('#more').addEventListener('click', () => api.showMenu());
document.querySelector('#tab-list').addEventListener('click', () => api.showTabs());
document.querySelector('#downloads').addEventListener('click', () => api.showDownloads());
document.querySelector('#profile').addEventListener('click', () => api.showProfile());

api.onDownloadProgress(({ active, percent }) => {
  const indicator = document.querySelector('#download-progress');
  const button = document.querySelector('#downloads');
  indicator.hidden = active < 1;
  indicator.classList.toggle('indeterminate', active > 0 && percent === null);
  button.classList.toggle('downloading', active > 0);
  if (active > 0 && percent !== null) {
    indicator.style.background = `conic-gradient(#1a73e8 ${percent}%, #dfe3e8 ${percent}% 100%)`;
  } else {
    indicator.style.background = '';
  }
  const label = active > 0
    ? `Baixando ${active} ${active === 1 ? 'arquivo' : 'arquivos'}${percent === null ? '' : ` — ${percent}%`}`
    : 'Downloads';
  button.title = label;
  button.setAttribute('aria-label', label);
});

address.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') address.blur();
});

api.onState(render);
api.onTheme((theme) => { document.documentElement.dataset.theme = theme; });
api.onFocusAddress(() => {
  address.focus();
  address.select();
});
api.getState().then(render);
