const api = window.openwebActivity;
const title = document.querySelector('#activity-title');
const subtitle = document.querySelector('#activity-subtitle');
const list = document.querySelector('#activity-list');
const actions = document.querySelector('#activity-actions');
let kind = 'history';

function addEmpty(message) {
  const empty = document.createElement('div');
  empty.className = 'empty-state';
  empty.textContent = message;
  list.append(empty);
}

function formatSize(bytes) {
  const value = Math.max(0, Number(bytes) || 0);
  if (value < 1000) return `${Math.round(value)} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let size = value;
  let unitIndex = -1;
  do {
    size /= 1000;
    unitIndex += 1;
  } while (size >= 1000 && unitIndex < units.length - 1);
  return `${new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 }).format(size)} ${units[unitIndex]}`;
}

function formatSpeed(bytesPerSecond) {
  const value = Math.max(0, Number(bytesPerSecond) || 0);
  if (!value) return 'calculando velocidade…';
  const megabits = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 }).format(value * 8 / 1_000_000);
  return `${formatSize(value)}/s (${megabits} Mbps)`;
}

function downloadStateLabel(state) {
  return ({
    downloading: 'Baixando',
    completed: 'Concluído',
    cancelled: 'Cancelado',
    interrupted: 'Interrompido'
  })[state] || state;
}

function renderEntry(entry) {
  const row = document.createElement('article');
  row.className = `activity-entry${kind === 'downloads' ? ' download-entry' : ''}`;
  if (kind === 'downloads') {
    const icon = document.createElement('img');
    icon.className = 'download-site-icon';
    icon.alt = '';
    icon.src = entry.faviconUrl || 'assets/openweb-logo.png';
    icon.onerror = () => {
      icon.onerror = null;
      icon.src = 'assets/openweb-logo.png';
    };
    row.append(icon);
  }
  const main = document.createElement('div');
  main.className = 'activity-entry-main';
  const name = document.createElement('div');
  name.className = 'activity-name';
  name.textContent = entry.title || entry.fileName || entry.url;
  const detail = document.createElement('div');
  detail.className = 'activity-detail';
  detail.textContent = kind === 'history'
    ? entry.url
    : entry.state === 'downloading'
      ? `${downloadStateLabel(entry.state)} · ${formatSize(entry.received)}${entry.total > 0 ? ` / ${formatSize(entry.total)}` : ''} · ${formatSpeed(entry.speedBytesPerSecond)}${entry.total > 0 ? ` · ${Math.min(100, Math.floor(entry.received * 100 / entry.total))}%` : ''}`
      : `${downloadStateLabel(entry.state)} · ${formatSize(entry.total || entry.received)}`;
  main.append(name, detail);
  row.append(main);

  if (kind === 'downloads' && entry.state === 'downloading') {
    const progress = document.createElement('div');
    progress.className = `download-progress-track${entry.total > 0 ? '' : ' indeterminate'}`;
    progress.setAttribute('role', 'progressbar');
    progress.setAttribute('aria-label', `Progresso de ${entry.fileName}`);
    if (entry.total > 0) {
      const percent = Math.min(100, Math.floor(entry.received * 100 / entry.total));
      progress.setAttribute('aria-valuemin', '0');
      progress.setAttribute('aria-valuemax', '100');
      progress.setAttribute('aria-valuenow', String(percent));
      const fill = document.createElement('span');
      fill.style.width = `${percent}%`;
      progress.append(fill);
    } else {
      progress.setAttribute('aria-valuetext', 'Baixando');
    }
    main.append(progress);
  }

  if (kind === 'history') {
    const open = document.createElement('button');
    open.className = 'secondary-button';
    open.textContent = 'Abrir';
    open.addEventListener('click', () => api.openHistory(entry.url));
    row.append(open);
  } else {
    const open = document.createElement('button');
    open.className = 'secondary-button';
    open.textContent = entry.state === 'completed' ? 'Abrir arquivo' : 'Mostrar na pasta';
    open.addEventListener('click', () => entry.state === 'completed'
      ? api.openDownload(entry.id)
      : api.showDownload(entry.id));
    row.append(open);
    if (entry.state === 'downloading') {
      const cancel = document.createElement('button');
      cancel.className = 'secondary-button cancel-download';
      cancel.textContent = 'Cancelar';
      cancel.setAttribute('aria-label', `Cancelar download de ${entry.fileName}`);
      cancel.addEventListener('click', () => api.cancelDownload(entry.id));
      row.append(cancel);
    }
  }
  return row;
}

async function refresh() {
  const data = await api.getData();
  if (!data) return;
  list.replaceChildren();
  actions.replaceChildren();

  if (kind === 'history') {
    title.textContent = 'Histórico';
    subtitle.textContent = 'Páginas visitadas neste dispositivo.';
    const clear = document.createElement('button');
    clear.className = 'secondary-button';
    clear.textContent = 'Limpar histórico';
    clear.addEventListener('click', () => api.clearHistory());
    actions.append(clear);
    if (data.history.length === 0) return addEmpty('Seu histórico está vazio.');
    for (const entry of data.history) list.append(renderEntry(entry));
    return;
  }

  title.textContent = 'Downloads';
  subtitle.textContent = 'Tamanhos em MB e GB (1 GB = 1000 MB).';
  const openFolder = document.createElement('button');
  openFolder.className = 'secondary-button';
  openFolder.textContent = 'Abrir pasta de downloads';
  openFolder.addEventListener('click', () => api.openDownloadsFolder());
  actions.append(openFolder);
  if (data.downloads.length === 0) return addEmpty('Nenhum download ainda.');
  for (const entry of data.downloads) list.append(renderEntry(entry));
}

api.onSetKind((nextKind) => { kind = nextKind === 'downloads' ? 'downloads' : 'history'; refresh(); });
api.onUpdated(refresh);
refresh();
