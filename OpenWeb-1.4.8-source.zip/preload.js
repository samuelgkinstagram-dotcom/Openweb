const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('openweb', {
  getState: () => ipcRenderer.invoke('browser:get-state'),
  navigate: (address) => ipcRenderer.invoke('browser:navigate', String(address)),
  back: () => ipcRenderer.invoke('browser:back'),
  forward: () => ipcRenderer.invoke('browser:forward'),
  reload: () => ipcRenderer.invoke('browser:reload'),
  newTab: (address) => ipcRenderer.invoke('browser:new-tab', address),
  closeTab: (id) => ipcRenderer.invoke('browser:close-tab', id),
  selectTab: (id) => ipcRenderer.invoke('browser:select-tab', id),
  showMenu: () => ipcRenderer.invoke('browser:show-menu'),
  showTabs: () => ipcRenderer.invoke('browser:show-tabs'),
  showDownloads: () => ipcRenderer.invoke('browser:show-downloads'),
  showProfile: () => ipcRenderer.invoke('browser:show-profile'),
  onDownloadProgress: (callback) => {
    const listener = (_event, progress) => callback(progress);
    ipcRenderer.on('browser:download-progress', listener);
    return () => ipcRenderer.removeListener('browser:download-progress', listener);
  },
  onState: (callback) => {
    const listener = (_event, state) => callback(state);
    ipcRenderer.on('browser:state', listener);
    return () => ipcRenderer.removeListener('browser:state', listener);
  },
  onFocusAddress: (callback) => {
    const listener = () => callback();
    ipcRenderer.on('browser:focus-address', listener);
    return () => ipcRenderer.removeListener('browser:focus-address', listener);
  },
  onTheme: (callback) => {
    const listener = (_event, theme) => callback(theme);
    ipcRenderer.on('browser:theme', listener);
    return () => ipcRenderer.removeListener('browser:theme', listener);
  }
});
