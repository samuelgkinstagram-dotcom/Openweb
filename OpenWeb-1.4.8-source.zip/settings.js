const api = window.openwebSettings;
const controls = {
  homePage: document.querySelector('#home-page'),
  searchEngine: document.querySelector('#search-engine'),
  theme: document.querySelector('#theme'),
  adBlockEnabled: document.querySelector('#ad-block-enabled'),
  performanceMode: document.querySelector('#performance-mode'),
  hardwareAcceleration: document.querySelector('#hardware-acceleration'),
  askDownloadLocation: document.querySelector('#ask-download-location')
};
const saveStatus = document.querySelector('#save-status');
let originalHardwareAcceleration = true;

function setPanel(name) {
  document.querySelectorAll('.settings-panel').forEach((panel) => {
    const selected = panel.id === `panel-${name}`;
    panel.hidden = !selected;
    panel.classList.toggle('active', selected);
  });
  document.querySelectorAll('.settings-nav-item').forEach((button) => {
    button.classList.toggle('active', button.dataset.panel === name);
  });
  const panel = document.querySelector(`#panel-${name}`);
  if (panel) document.title = `${panel.dataset.title} - Configurações do OpenWeb`;
}

function describeAdBlockStatus(status) {
  const descriptions = {
    loading: 'Carregando os filtros de anúncios…',
    active: 'Bloqueio de anúncios ativo.',
    disabled: 'Bloqueio de anúncios desativado.',
    unavailable: 'Não foi possível carregar os filtros. Verifique a conexão e reabra as configurações.'
  };
  document.querySelector('#ad-block-status').textContent = descriptions[status] || descriptions.loading;
}

function describeGraphics(settings) {
  const features = settings?.graphics?.features || {};
  const accelerated = ['gpu_compositing', 'webgl', 'rasterization']
    .some((feature) => String(features[feature] || '').startsWith('enabled'));
  const available = settings?.graphics?.enabled && accelerated;
  const description = available
    ? 'A GPU está ativa para composição e recursos 3D.'
    : 'O sistema pode usar renderização por software.';
  document.querySelector('#graphics-status').textContent = description;
  document.querySelector('#system-graphics-status').textContent = description;
}

function describePerformanceMode() {
  document.querySelector('#performance-description').textContent = controls.performanceMode.value === 'maximum'
    ? 'Mantém abas em segundo plano ativas para jogos e tarefas contínuas. Pode usar mais memória e energia.'
    : 'Reduz atividade de abas em segundo plano para equilibrar o uso de memória e energia.';
}

api.get().then((settings) => {
  if (!settings) return;
  controls.homePage.value = settings.homePage;
  controls.searchEngine.value = settings.searchEngine;
  controls.theme.value = settings.theme;
  controls.adBlockEnabled.checked = settings.adBlockEnabled !== false;
  controls.performanceMode.value = settings.performanceMode === 'balanced' ? 'balanced' : 'maximum';
  controls.hardwareAcceleration.checked = settings.hardwareAcceleration !== false;
  originalHardwareAcceleration = controls.hardwareAcceleration.checked;
  controls.askDownloadLocation.checked = settings.askDownloadLocation === true;
  document.querySelector('#download-path').textContent = settings.downloadDirectory;
  document.documentElement.dataset.theme = settings.theme;
  document.querySelector('#make-default').textContent = settings.isDefaultBrowser ? 'Já é o padrão' : 'Tornar padrão';
  describeAdBlockStatus(settings.adBlockStatus);
  describeGraphics(settings);
  describePerformanceMode();
}).catch(() => {});

api.onAdBlockStatus(describeAdBlockStatus);
api.onDownloadProgress(({ active, percent }) => {
  const status = document.querySelector('#settings-download-status');
  const label = document.querySelector('#settings-download-label');
  const progressCard = document.querySelector('#settings-download-progress');
  const progressTitle = document.querySelector('#settings-download-progress-title');
  const progressDetail = document.querySelector('#settings-download-progress-detail');
  const progressTrack = document.querySelector('#settings-download-track');
  const progressFill = document.querySelector('#settings-download-fill');
  status.hidden = active < 1;
  label.textContent = active > 0
    ? `Baixando ${active} ${active === 1 ? 'arquivo' : 'arquivos'}${percent === null ? '' : ` — ${percent}%`}`
    : 'Downloads';
  progressCard.hidden = active < 1;
  progressTitle.textContent = active === 1 ? 'Download em andamento' : `${active} downloads em andamento`;
  progressDetail.textContent = percent === null
    ? 'Baixando arquivo…'
    : `Baixando arquivo… ${percent}%`;
  progressTrack.hidden = percent === null;
  progressFill.style.width = `${percent ?? 0}%`;
});
document.querySelectorAll('.settings-nav-item').forEach((button) => {
  button.addEventListener('click', () => setPanel(button.dataset.panel));
});
document.querySelectorAll('[data-open-panel]').forEach((button) => {
  button.addEventListener('click', () => setPanel(button.dataset.openPanel));
});
controls.performanceMode.addEventListener('change', describePerformanceMode);

document.querySelector('#settings-search').addEventListener('input', (event) => {
  const query = event.target.value.trim().toLocaleLowerCase('pt-BR');
  if (!query) return;
  const match = [...document.querySelectorAll('.settings-nav-item')]
    .find((button) => button.textContent.toLocaleLowerCase('pt-BR').includes(query));
  if (match) setPanel(match.dataset.panel);
});

document.querySelector('#save').addEventListener('click', async () => {
  const restartRequired = controls.hardwareAcceleration.checked !== originalHardwareAcceleration;
  const restartNow = restartRequired && window.confirm('A alteração da aceleração gráfica será aplicada ao reiniciar. Salvar e reiniciar o OpenWeb agora?');
  await api.save({
    homePage: controls.homePage.value.trim(),
    searchEngine: controls.searchEngine.value,
    theme: controls.theme.value,
    adBlockEnabled: controls.adBlockEnabled.checked,
    performanceMode: controls.performanceMode.value,
    hardwareAcceleration: controls.hardwareAcceleration.checked,
    askDownloadLocation: controls.askDownloadLocation.checked,
    downloadDirectory: document.querySelector('#download-path').textContent
  }, restartNow);
  originalHardwareAcceleration = controls.hardwareAcceleration.checked;
  document.documentElement.dataset.theme = controls.theme.value;
  saveStatus.textContent = restartRequired && !restartNow
    ? 'Salvo. Reinicie o OpenWeb para aplicar a aceleração gráfica.'
    : 'Configurações salvas';
  window.setTimeout(() => { saveStatus.textContent = ''; }, 3500);
});

document.querySelector('#change-download-path').addEventListener('click', async () => {
  const directory = await api.chooseDownloadDirectory();
  if (directory) document.querySelector('#download-path').textContent = directory;
});

document.querySelector('#open-downloads-folder').addEventListener('click', () => api.openDownloadsFolder());

document.querySelector('#make-default').addEventListener('click', async () => {
  const opened = await api.setDefaultBrowser();
  saveStatus.textContent = opened
    ? 'Abra Apps padrão do Windows e escolha o OpenWeb para HTTP e HTTPS.'
    : 'O Windows abrirá as configurações de aplicativos padrão.';
});

document.querySelector('#clear-data').addEventListener('click', async () => {
  if (!window.confirm('Apagar histórico, cookies, cache e dados dos sites?')) return;
  await api.clearData();
  saveStatus.textContent = 'Dados de navegação apagados';
  window.setTimeout(() => { saveStatus.textContent = ''; }, 2600);
});
