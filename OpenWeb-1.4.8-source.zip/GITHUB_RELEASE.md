# Texto para publicar no GitHub

## Descrição curta do repositório

Navegador de código aberto para Windows x64, feito com Electron e Chromium. Inclui aceleração gráfica, modos de desempenho e downloads com progresso, velocidade e cancelamento. O código-fonte pode ser modificado sob licença MIT.

## Título da release

OpenWeb 1.4.8 para Windows x64

## Descrição da release

O OpenWeb 1.4.8 é um navegador para Windows com abas, pesquisa, histórico, bloqueador de anúncios e acesso rápido aos downloads. A lista de downloads exibe o ícone do site, porcentagem, velocidade em MB/s e Mbps, tamanho em MB/GB e permite cancelar arquivos em andamento. Os tamanhos usam base decimal: 1 GB = 1000 MB. Esta versão também mostra progresso na seção Downloads das configurações, oculta a barra do navegador durante vídeos em tela cheia, corrige o ícone do aplicativo e restaura as abas abertas ao reiniciar. Configurações, histórico, cookies e arquivos baixados permanecem salvos durante atualizações. Use F11 para alternar a tela cheia do navegador. As configurações permitem escolher entre alto desempenho e modo equilibrado, ajustar a aceleração gráfica, selecionar a pasta de downloads e definir o OpenWeb como navegador padrão pelo Windows.

**Requisitos mínimos:** Windows 10 ou posterior (64 bits), processador x64, 4 GB de RAM, cerca de 500 MB livres para instalação e conexão com a internet. Para várias abas e jogos web, recomendamos 8 GB de RAM e um driver gráfico atualizado.

**Instalação:** baixe `OpenWeb-1.4.8-x64.exe` em Assets e execute o instalador. Ele instala ou atualiza uma instalação existente do OpenWeb. A logo OpenWeb aparece no instalador e nos atalhos do navegador.

**Código-fonte:** baixe `OpenWeb-1.4.8-source.zip` em Assets para consultar, compilar ou modificar o projeto. O código do OpenWeb está sob a licença MIT; as dependências mantêm suas próprias licenças.

**Notas:** a aceleração gráfica depende do computador e do driver. A velocidade dos downloads depende da conexão e do servidor do site. A retomada de downloads depende do suporte do servidor. O executável não está assinado digitalmente, então o Windows pode exibir um aviso.

O OpenWeb usa Electron e Chromium. A interface é feita em HTML, CSS e JavaScript; o projeto não é inteiramente escrito em C.
