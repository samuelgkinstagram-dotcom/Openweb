const { app, BrowserWindow, WebContentsView, ipcMain, Menu, session, shell, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const { ElectronBlocker } = require('@ghostery/adblocker-electron');

const TOOLBAR_HEIGHT = 100;
const HOME_URL = 'https://www.google.com';
const PARTITION = 'persist:openweb';
const SEARCH_URLS = {
  google: 'https://www.google.com/search?q=',
  bing: 'https://www.bing.com/search?q=',
  duckduckgo: 'https://duckduckgo.com/?q='
};

let mainWindow;
let chromeView;
let htmlFullscreenTabId = null;
let wasWindowFullscreenBeforeHtmlFullscreen = false;
let tabs = [];
let activeTabId;
let nextTabId = 1;
let settingsWindow;
let activityWindow;
let browserSession;
let preferences = {
  homePage: HOME_URL,
  searchEngine: 'google',
  theme: 'light',
  adBlockEnabled: true,
  performanceMode: 'maximum',
  hardwareAcceleration: true,
  askDownloadLocation: false
};
let adBlocker;
let adBlockerPromise;
let adBlockStatus = 'loading';
let historyItems = [];
let downloadItems = [];
let nextDownloadId = 1;
let sessionSaveTimer;
const pendingImageDownloads = new Set();
const reservedDownloadPaths = new Set();

let startupPreferences = {};
try {
  startupPreferences = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'preferences.json'), 'utf8'));
} catch {
  // Use the default startup preferences on the first run.
}
if (startupPreferences.hardwareAcceleration === false) app.disableHardwareAcceleration();
app.userAgentFallback = app.userAgentFallback.replace(/\sElectron\/[^\s]+/g, '');

// Keep Chromium's standard GPU selection enabled for WebGL and canvas games.

function readJson(fileName, fallback) {
  try {
    return JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), fileName), 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(fileName, value) {
  try {
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    fs.writeFileSync(path.join(app.getPath('userData'), fileName), JSON.stringify(value, null, 2));
  } catch (error) {
    console.error(`Could not save ${fileName}:`, error.message);
  }
}

function searchAddress(query) {
  const engine = SEARCH_URLS[preferences.searchEngine] ? preferences.searchEngine : 'google';
  return `${SEARCH_URLS[engine]}${encodeURIComponent(query)}`;
}

function safeAddress(input) {
  const value = String(input ?? '').trim();
  if (!value) return preferences.homePage || HOME_URL;

  try {
    const looksLikeHost = /^(localhost|127\.0\.0\.1|[a-z0-9-]+(?:\.[a-z0-9-]+)+)(:\d+)?(?:\/.*)?$/i.test(value);
    if (!/^https?:\/\//i.test(value) && !looksLikeHost) return searchAddress(value);
    const candidate = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
    if (candidate.protocol === 'http:' || candidate.protocol === 'https:') return candidate.href;
  } catch {
    // Treat non-URLs as a search query.
  }

  return searchAddress(value);
}

function recordHistory(url, title = '') {
  if (!/^https?:\/\//i.test(url)) return;
  historyItems = [
    { url, title: title || url, visitedAt: new Date().toISOString() },
    ...historyItems.filter((entry) => entry.url !== url)
  ].slice(0, 500);
  writeJson('history.json', historyItems);
  notifyActivity();
}

function updateHistoryTitle(url, title) {
  if (!title || !url) return;
  const entry = historyItems.find((item) => item.url === url);
  if (!entry || entry.title === title) return;
  entry.title = title;
  writeJson('history.json', historyItems);
  notifyActivity();
}

function saveBrowserSession() {
  clearTimeout(sessionSaveTimer);
  sessionSaveTimer = setTimeout(saveBrowserSessionNow, 300);
  sessionSaveTimer.unref?.();
}

function saveBrowserSessionNow() {
  clearTimeout(sessionSaveTimer);
  const savedTabs = tabs.map((tab) => tab.view.webContents.getURL() || tab.lastKnownUrl)
    .filter((url) => /^https?:\/\//i.test(url));
  const activeIndex = Math.max(0, tabs.findIndex((tab) => tab.id === activeTabId));
  writeJson('session.json', { tabs: savedTabs, activeIndex });
}

function notifyActivity() {
  if (activityWindow && !activityWindow.isDestroyed()) activityWindow.webContents.send('activity:updated');
}

function notifyDownloadProgress() {
  const active = downloadItems.filter((item) => item.state === 'downloading');
  const received = active.reduce((sum, item) => sum + item.received, 0);
  const hasKnownTotals = active.length > 0 && active.every((item) => item.total > 0);
  const total = hasKnownTotals ? active.reduce((sum, item) => sum + item.total, 0) : 0;
  const progress = {
    active: active.length,
    percent: total > 0 ? Math.min(100, Math.round((received / total) * 100)) : null
  };
  if (chromeView && !chromeView.webContents.isDestroyed()) {
    chromeView.webContents.send('browser:download-progress', progress);
  }
  if (settingsWindow && !settingsWindow.isDestroyed()) {
    settingsWindow.webContents.send('settings:download-progress', progress);
  }
}

function notifyAdBlockStatus() {
  if (settingsWindow && !settingsWindow.isDestroyed()) {
    settingsWindow.webContents.send('settings:adblock-status', adBlockStatus);
  }
}

async function applyAdBlocker() {
  if (!browserSession) return;
  if (!preferences.adBlockEnabled) {
    adBlocker?.disableBlockingInSession(browserSession);
    adBlockStatus = 'disabled';
    notifyAdBlockStatus();
    return;
  }

  adBlockStatus = 'loading';
  notifyAdBlockStatus();
  try {
    if (!adBlocker) {
      if (!adBlockerPromise) {
        const cachePath = path.join(app.getPath('userData'), 'adblocker-engine.bin');
        adBlockerPromise = ElectronBlocker.fromPrebuiltAdsOnly(globalThis.fetch, {
          path: cachePath,
          read: (filePath) => fs.promises.readFile(filePath),
          write: (filePath, bytes) => {
            fs.mkdirSync(path.dirname(filePath), { recursive: true });
            return fs.promises.writeFile(filePath, bytes);
          }
        });
      }
      adBlocker = await adBlockerPromise;
    }
    if (preferences.adBlockEnabled) {
      adBlocker.enableBlockingInSession(browserSession);
      adBlockStatus = 'active';
    } else {
      adBlocker.disableBlockingInSession(browserSession);
      adBlockStatus = 'disabled';
    }
  } catch (error) {
    adBlockerPromise = undefined;
    adBlockStatus = 'unavailable';
    console.warn('Ad blocking could not be initialized:', error.message);
  }
  notifyAdBlockStatus();
}

function registerDownloads() {
  browserSession.on('will-download', (_event, item, sourceContents) => {
    const imageDownload = pendingImageDownloads.delete(item.getURL());
    if (imageDownload) {
      item.setSavePath(uniqueDownloadPath(item.getFilename(), app.getPath('downloads')));
    } else if (preferences.askDownloadLocation) {
      item.pause();
      dialog.showSaveDialog(mainWindow, {
        defaultPath: path.join(getDownloadDirectory(), item.getFilename()),
        title: 'Salvar download'
      }).then(({ canceled, filePath }) => {
        if (canceled || !filePath) {
          item.cancel();
          return;
        }
        item.setSavePath(filePath);
        item.resume();
      }).catch(() => item.cancel());
    } else {
      item.setSavePath(uniqueDownloadPath(item.getFilename(), getDownloadDirectory()));
    }
    const sourceTab = tabs.find((tab) => tab.view.webContents === sourceContents);
    const entry = {
      id: nextDownloadId++,
      fileName: item.getFilename(),
      url: item.getURL(),
      faviconUrl: sourceTab?.favIconUrl || '',
      path: item.getSavePath(),
      state: 'downloading',
      received: 0,
      total: item.getTotalBytes(),
      speedBytesPerSecond: 0,
      lastProgressAt: Date.now(),
      lastReceivedBytes: item.getReceivedBytes(),
      item
    };
    downloadItems.unshift(entry);
    item.on('updated', (_updateEvent, state) => {
      entry.path = item.getSavePath();
      entry.received = item.getReceivedBytes();
      entry.total = item.getTotalBytes();
      const now = Date.now();
      const elapsed = now - entry.lastProgressAt;
      if (elapsed > 0) {
        const instantSpeed = Math.max(0, (entry.received - entry.lastReceivedBytes) * 1000 / elapsed);
        entry.speedBytesPerSecond = entry.speedBytesPerSecond > 0
          ? entry.speedBytesPerSecond * 0.7 + instantSpeed * 0.3
          : instantSpeed;
      }
      entry.lastProgressAt = now;
      entry.lastReceivedBytes = entry.received;
      if (state === 'interrupted') entry.state = 'interrupted';
      if (state === 'progressing') entry.state = 'downloading';
      notifyActivity();
      notifyDownloadProgress();
    });
    item.once('done', (_doneEvent, state) => {
      entry.path = item.getSavePath();
      entry.received = item.getReceivedBytes();
      entry.total = item.getTotalBytes();
      entry.state = state;
      entry.speedBytesPerSecond = 0;
      reservedDownloadPaths.delete(entry.path);
      notifyActivity();
      notifyDownloadProgress();
    });
    notifyActivity();
    notifyDownloadProgress();
  });
}

function getDownloadDirectory() {
  return typeof preferences.downloadDirectory === 'string' && preferences.downloadDirectory
    ? preferences.downloadDirectory
    : app.getPath('downloads');
}

function uniqueDownloadPath(fileName, downloadDirectory = app.getPath('downloads')) {
  const safeName = path.basename(String(fileName || 'image'))
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, '_')
    .replace(/[ .]+$/g, '') || 'image';
  fs.mkdirSync(downloadDirectory, { recursive: true });
  const extension = path.extname(safeName);
  const baseName = path.basename(safeName, extension);
  let candidate = path.join(downloadDirectory, safeName);
  let index = 1;
  while (fs.existsSync(candidate) || reservedDownloadPaths.has(candidate)) {
    candidate = path.join(downloadDirectory, `${baseName} (${index++})${extension}`);
  }
  reservedDownloadPaths.add(candidate);
  return candidate;
}

function attachContextMenu(contents) {
  contents.on('context-menu', (_event, params) => {
    const template = [];
    if (params.isEditable) {
      template.push(
        { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' },
        { type: 'separator' }
      );
    } else if (params.selectionText) {
      template.push({ role: 'copy' }, { type: 'separator' });
    }

    if (params.mediaType === 'image' && /^https?:\/\//i.test(params.srcURL || '')) {
      template.push({
        label: 'Salvar imagem em Downloads',
        click: () => {
          pendingImageDownloads.add(params.srcURL);
          contents.downloadURL(params.srcURL);
        }
      });
      template.push({
        label: 'Abrir imagem em nova aba',
        click: () => createTab(params.srcURL)
      });
      template.push({
        label: 'Copiar endereço da imagem',
        click: () => contents.copyImageAt(params.x, params.y)
      });
      template.push({ type: 'separator' });
    }

    template.push({
      label: 'Inspecionar elemento',
      click: () => {
        contents.openDevTools({ mode: 'detach' });
        contents.inspectElement(params.x, params.y);
      }
    });
    template.push({ label: 'Recarregar', click: () => contents.reload() });
    Menu.buildFromTemplate(template).popup({ window: mainWindow });
  });
}

function currentTab() {
  return tabs.find((tab) => tab.id === activeTabId);
}

function tabState(tab) {
  const contents = tab.view.webContents;
  return {
    id: tab.id,
    title: contents.getTitle() || 'Nova guia',
    url: contents.getURL() || '',
    favIconUrl: tab.favIconUrl || '',
    loading: contents.isLoading(),
    canGoBack: contents.canGoBack(),
    canGoForward: contents.canGoForward(),
    active: tab.id === activeTabId
  };
}

function sendState() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  chromeView.webContents.send('browser:state', {
    tabs: tabs.map(tabState),
    activeTabId
  });
  const tab = currentTab();
  mainWindow.setTitle(tab?.view.webContents.getTitle()
    ? `OpenWeb — ${tab.view.webContents.getTitle()}`
    : 'OpenWeb');
}

function layoutViews() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const [width, height] = mainWindow.getContentSize();
  const active = currentTab();
  const pageIsFullscreen = active?.id === htmlFullscreenTabId;
  chromeView.setBounds({
    x: 0,
    y: 0,
    width,
    height: pageIsFullscreen ? 0 : TOOLBAR_HEIGHT
  });
  if (!active) return;

  for (const tab of tabs) {
    mainWindow.contentView.removeChildView(tab.view);
  }
  mainWindow.contentView.addChildView(active.view);
  active.view.setBounds({
    x: 0,
    y: pageIsFullscreen ? 0 : TOOLBAR_HEIGHT,
    width,
    height: Math.max(0, height - (pageIsFullscreen ? 0 : TOOLBAR_HEIGHT))
  });
}

function createTab(address = '') {
  const view = new WebContentsView({
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      partition: PARTITION,
      backgroundThrottling: preferences.performanceMode !== 'maximum'
    }
  });
  const tab = { id: nextTabId++, view };
  tab.lastKnownUrl = safeAddress(address);
  tabs.push(tab);

  const contents = view.webContents;
  attachShortcuts(contents);
  attachContextMenu(contents);
  contents.on('page-title-updated', () => {
    sendState();
    updateHistoryTitle(contents.getURL(), contents.getTitle());
  });
  contents.on('page-favicon-updated', (_event, favicons) => {
    tab.favIconUrl = Array.isArray(favicons) ? (favicons[0] || '') : '';
    sendState();
  });
  contents.on('did-start-loading', sendState);
  contents.on('did-stop-loading', sendState);
  contents.on('did-navigate', (_event, url) => {
    tab.lastKnownUrl = url;
    sendState();
    saveBrowserSession();
  });
  contents.on('did-navigate', (_event, url) => recordHistory(url, contents.getTitle()));
  contents.on('did-navigate-in-page', () => { sendState(); saveBrowserSession(); });
  contents.on('render-process-gone', sendState);
  contents.on('enter-html-full-screen', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    htmlFullscreenTabId = tab.id;
    wasWindowFullscreenBeforeHtmlFullscreen = mainWindow.isFullScreen();
    if (!wasWindowFullscreenBeforeHtmlFullscreen) mainWindow.setFullScreen(true);
    layoutViews();
  });
  contents.on('leave-html-full-screen', () => {
    if (htmlFullscreenTabId !== tab.id) return;
    htmlFullscreenTabId = null;
    if (mainWindow && !mainWindow.isDestroyed()
      && mainWindow.isFullScreen() !== wasWindowFullscreenBeforeHtmlFullscreen) {
      mainWindow.setFullScreen(wasWindowFullscreenBeforeHtmlFullscreen);
    }
    layoutViews();
  });
  contents.setWindowOpenHandler(({ url }) => {
    createTab(url);
    return { action: 'deny' };
  });

  contents.loadURL(safeAddress(address)).catch(() => {});
  activeTabId = tab.id;
  layoutViews();
  sendState();
  saveBrowserSession();
  return tab;
}

function closeTab(id = activeTabId) {
  const index = tabs.findIndex((tab) => tab.id === id);
  if (index < 0) return;
  const [tab] = tabs.splice(index, 1);
  mainWindow.contentView.removeChildView(tab.view);
  tab.view.webContents.close();
  saveBrowserSession();

  if (tabs.length === 0) {
    createTab();
    return;
  }
  if (activeTabId === id) activeTabId = tabs[Math.max(0, index - 1)].id;
  layoutViews();
  sendState();
}

function isChromeSender(event) {
  return Boolean(mainWindow && !mainWindow.isDestroyed() && event.sender === chromeView.webContents);
}

function openSettings() {
  if (settingsWindow && !settingsWindow.isDestroyed()) {
    settingsWindow.focus();
    return;
  }
  settingsWindow = new BrowserWindow({
    width: 1120,
    height: 780,
    minWidth: 820,
    minHeight: 620,
    resizable: true,
    title: 'Configurações do OpenWeb',
    parent: mainWindow,
    backgroundColor: '#f5f7fa',
    webPreferences: {
      preload: path.join(__dirname, 'settings-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  settingsWindow.loadFile(path.join(__dirname, 'settings.html'));
  settingsWindow.webContents.once('did-finish-load', notifyDownloadProgress);
  settingsWindow.on('closed', () => { settingsWindow = undefined; });
}

function openActivity(kind) {
  if (activityWindow && !activityWindow.isDestroyed()) {
    activityWindow.webContents.send('activity:set-kind', kind);
    activityWindow.focus();
    return;
  }
  activityWindow = new BrowserWindow({
    width: 780,
    height: 620,
    minWidth: 540,
    minHeight: 420,
    title: kind === 'history' ? 'Histórico - OpenWeb' : 'Downloads - OpenWeb',
    parent: mainWindow,
    backgroundColor: '#f5f7fa',
    webPreferences: {
      preload: path.join(__dirname, 'activity-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  activityWindow.loadFile(path.join(__dirname, 'activity.html'));
  activityWindow.webContents.once('did-finish-load', () => activityWindow?.webContents.send('activity:set-kind', kind));
  activityWindow.on('closed', () => { activityWindow = undefined; });
}

function showBrowserMenu() {
  const menu = Menu.buildFromTemplate([
    { label: 'Nova aba', accelerator: 'Ctrl+T', click: () => createTab() },
    { label: mainWindow?.isFullScreen() ? 'Sair da tela cheia' : 'Tela cheia', accelerator: 'F11', click: () => mainWindow?.setFullScreen(!mainWindow.isFullScreen()) },
    { type: 'separator' },
    { label: 'Histórico', click: () => openActivity('history') },
    { label: 'Downloads', click: () => openActivity('downloads') },
    { type: 'separator' },
    { label: 'Configurações', click: openSettings },
    { label: 'Sobre o OpenWeb', click: () => dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'Sobre o OpenWeb',
      message: `OpenWeb ${app.getVersion()}`,
      detail: 'Navegador desktop baseado no Chromium incluído no Electron.'
    }) }
  ]);
  menu.popup({ window: mainWindow });
}

function showTabsMenu() {
  const template = tabs.map((tab) => ({
    label: tab.view.webContents.getTitle() || 'Nova guia',
    type: 'radio',
    checked: tab.id === activeTabId,
    click: () => {
      activeTabId = tab.id;
      layoutViews();
      sendState();
    }
  }));
  template.push({ type: 'separator' }, { label: 'Nova aba', accelerator: 'Ctrl+T', click: () => createTab() });
  Menu.buildFromTemplate(template).popup({ window: mainWindow });
}

function showProfileMenu() {
  Menu.buildFromTemplate([
    { label: 'Perfil local do OpenWeb', enabled: false },
    { type: 'separator' },
    { label: 'Configurações', click: openSettings },
    { label: 'Sobre o OpenWeb', click: () => dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'Sobre o OpenWeb',
      message: `OpenWeb ${app.getVersion()}`,
      detail: 'Navegador desktop baseado no Chromium incluído no Electron.'
    }) }
  ]).popup({ window: mainWindow });
}

function attachShortcuts(contents) {
  contents.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return;
    const key = input.key.toLowerCase();
    if ((input.control || input.meta) && key === 'l') {
      event.preventDefault();
      chromeView.webContents.send('browser:focus-address');
    } else if ((input.control || input.meta) && key === 't') {
      event.preventDefault();
      createTab();
    } else if ((input.control || input.meta) && key === 'w') {
      event.preventDefault();
      closeTab();
    } else if ((input.control || input.meta) && key === 'r') {
      event.preventDefault();
      currentTab()?.view.webContents.reload();
    } else if (key === 'f5') {
      event.preventDefault();
      currentTab()?.view.webContents.reload();
    } else if (key === 'f11') {
      event.preventDefault();
      mainWindow?.setFullScreen(!mainWindow.isFullScreen());
    } else if (key === 'escape' && mainWindow?.isFullScreen()) {
      event.preventDefault();
      mainWindow.setFullScreen(false);
    }
  });
}

function registerIpc() {
  ipcMain.handle('browser:get-state', (event) => isChromeSender(event) ? {
    tabs: tabs.map(tabState), activeTabId
  } : null);
  ipcMain.handle('browser:navigate', (event, address) => {
    if (!isChromeSender(event)) return;
    currentTab()?.view.webContents.loadURL(safeAddress(address)).catch(() => {});
  });
  ipcMain.handle('browser:back', (event) => {
    if (isChromeSender(event) && currentTab()?.view.webContents.canGoBack()) currentTab().view.webContents.goBack();
  });
  ipcMain.handle('browser:forward', (event) => {
    if (isChromeSender(event) && currentTab()?.view.webContents.canGoForward()) currentTab().view.webContents.goForward();
  });
  ipcMain.handle('browser:reload', (event) => {
    if (isChromeSender(event)) currentTab()?.view.webContents.reload();
  });
  ipcMain.handle('browser:new-tab', (event, address) => {
    if (isChromeSender(event)) createTab(address || '');
  });
  ipcMain.handle('browser:close-tab', (event, id) => {
    if (isChromeSender(event)) closeTab(Number.isInteger(id) ? id : activeTabId);
  });
  ipcMain.handle('browser:select-tab', (event, id) => {
    if (!isChromeSender(event) || !tabs.some((tab) => tab.id === id)) return;
    activeTabId = id;
    layoutViews();
    sendState();
    saveBrowserSession();
  });
  ipcMain.handle('browser:show-menu', (event) => {
    if (isChromeSender(event)) showBrowserMenu();
  });
  ipcMain.handle('browser:show-tabs', (event) => {
    if (isChromeSender(event)) showTabsMenu();
  });
  ipcMain.handle('browser:show-downloads', (event) => {
    if (isChromeSender(event)) openActivity('downloads');
  });
  ipcMain.handle('browser:show-profile', (event) => {
    if (isChromeSender(event)) showProfileMenu();
  });
  ipcMain.handle('settings:get', (event) => event.sender === settingsWindow?.webContents ? {
    ...preferences,
    downloadDirectory: getDownloadDirectory(),
    isDefaultBrowser: app.isDefaultProtocolClient('http') && app.isDefaultProtocolClient('https'),
    adBlockStatus,
    graphics: {
      enabled: app.isHardwareAccelerationEnabled(),
      features: app.getGPUFeatureStatus()
    }
  } : null);
  ipcMain.handle('settings:save', (event, nextPreferences, restartNow) => {
    if (event.sender !== settingsWindow?.webContents || !nextPreferences || typeof nextPreferences !== 'object') return null;
    const homePage = safeAddress(nextPreferences.homePage);
    const restartRequired = preferences.hardwareAcceleration !== (nextPreferences.hardwareAcceleration !== false);
    preferences = {
      homePage,
      searchEngine: SEARCH_URLS[nextPreferences.searchEngine] ? nextPreferences.searchEngine : 'google',
      theme: nextPreferences.theme === 'dark' ? 'dark' : 'light',
      adBlockEnabled: nextPreferences.adBlockEnabled !== false,
      performanceMode: nextPreferences.performanceMode === 'balanced' ? 'balanced' : 'maximum',
      hardwareAcceleration: nextPreferences.hardwareAcceleration !== false,
      downloadDirectory: typeof nextPreferences.downloadDirectory === 'string' && nextPreferences.downloadDirectory
        ? nextPreferences.downloadDirectory
        : app.getPath('downloads'),
      askDownloadLocation: nextPreferences.askDownloadLocation === true
    };
    writeJson('preferences.json', preferences);
    for (const tab of tabs) {
      tab.view.webContents.setBackgroundThrottling(preferences.performanceMode !== 'maximum');
    }
    chromeView.webContents.send('browser:theme', preferences.theme);
    sendState();
    void applyAdBlocker();
    if (restartNow && restartRequired) {
      setTimeout(() => {
        app.relaunch();
        app.exit(0);
      }, 500);
    }
    return { restartRequired };
  });
  ipcMain.handle('settings:choose-download-directory', async (event) => {
    if (event.sender !== settingsWindow?.webContents) return null;
    const result = await dialog.showOpenDialog(settingsWindow, {
      title: 'Escolher pasta de downloads',
      defaultPath: getDownloadDirectory(),
      properties: ['openDirectory', 'createDirectory']
    });
    return result.canceled ? null : result.filePaths[0];
  });
  ipcMain.handle('settings:open-downloads-folder', (event) => {
    if (event.sender === settingsWindow?.webContents) shell.openPath(getDownloadDirectory());
  });
  ipcMain.handle('settings:set-default-browser', async (event) => {
    if (event.sender !== settingsWindow?.webContents) return false;
    if (process.platform === 'win32') {
      app.setAsDefaultProtocolClient('http');
      app.setAsDefaultProtocolClient('https');
      await shell.openExternal('ms-settings:defaultapps');
      return true;
    }
    return false;
  });
  ipcMain.handle('settings:clear-data', async (event) => {
    if (event.sender !== settingsWindow?.webContents) return false;
    historyItems = [];
    writeJson('history.json', historyItems);
    await browserSession.clearStorageData();
    await browserSession.clearCache();
    notifyActivity();
    return true;
  });
  ipcMain.handle('activity:get-data', (event) => event.sender === activityWindow?.webContents ? {
    history: historyItems,
    downloads: downloadItems.map(({ id, fileName, url, faviconUrl, path: filePath, state, received, total, speedBytesPerSecond }) => ({
      id, fileName, url, faviconUrl, path: filePath, state, received, total, speedBytesPerSecond
    }))
  } : null);
  ipcMain.handle('activity:open-history', (event, url) => {
    if (event.sender !== activityWindow?.webContents || !/^https?:\/\//i.test(url)) return;
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.show();
      mainWindow.focus();
      createTab(url);
    }
  });
  ipcMain.handle('activity:open-download', async (event, id) => {
    if (event.sender !== activityWindow?.webContents) return;
    const item = downloadItems.find((download) => download.id === id && download.state === 'completed' && download.path);
    if (item) await shell.openPath(item.path);
  });
  ipcMain.handle('activity:show-download', (event, id) => {
    if (event.sender !== activityWindow?.webContents) return;
    const item = downloadItems.find((download) => download.id === id && download.path);
    if (item) shell.showItemInFolder(item.path);
  });
  ipcMain.handle('activity:cancel-download', (event, id) => {
    if (event.sender !== activityWindow?.webContents) return false;
    const item = downloadItems.find((download) => download.id === id && download.state === 'downloading');
    if (!item?.item) return false;
    item.item.cancel();
    return true;
  });
  ipcMain.handle('activity:open-downloads-folder', (event) => {
    if (event.sender === activityWindow?.webContents) shell.openPath(app.getPath('downloads'));
  });
  ipcMain.handle('activity:clear-history', (event) => {
    if (event.sender !== activityWindow?.webContents) return;
    historyItems = [];
    writeJson('history.json', historyItems);
    notifyActivity();
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    icon: path.join(__dirname, 'assets', 'openweb.ico'),
    width: 1360,
    height: 900,
    minWidth: 720,
    minHeight: 480,
    backgroundColor: '#f5f7fa',
    title: 'OpenWeb',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  chromeView = new WebContentsView({
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow.contentView.addChildView(chromeView);
  mainWindow.setFullScreen(true);
  chromeView.webContents.loadFile(path.join(__dirname, 'index.html'));
  chromeView.webContents.once('did-finish-load', () => {
    chromeView.webContents.send('browser:theme', preferences.theme);
    notifyDownloadProgress();
  });
  mainWindow.on('resize', layoutViews);
  mainWindow.on('close', saveBrowserSessionNow);
  mainWindow.on('closed', () => {
    for (const tab of tabs) tab.view.webContents.close();
    tabs = [];
    mainWindow = undefined;
  });
  const savedSession = readJson('session.json', {});
  const savedUrls = Array.isArray(savedSession.tabs)
    ? savedSession.tabs.filter((url) => typeof url === 'string' && /^https?:\/\//i.test(url)).slice(0, 50)
    : [];
  if (savedUrls.length) {
    for (const url of savedUrls) createTab(url);
    const activeIndex = Number.isInteger(savedSession.activeIndex)
      ? Math.min(Math.max(savedSession.activeIndex, 0), tabs.length - 1)
      : tabs.length - 1;
    activeTabId = tabs[activeIndex].id;
    layoutViews();
    sendState();
  } else {
    createTab();
  }

  attachShortcuts(chromeView.webContents);
}

app.whenReady().then(() => {
  const savedPreferences = readJson('preferences.json', {});
  preferences = {
    homePage: typeof savedPreferences.homePage === 'string' ? savedPreferences.homePage : HOME_URL,
    searchEngine: SEARCH_URLS[savedPreferences.searchEngine] ? savedPreferences.searchEngine : 'google',
    theme: savedPreferences.theme === 'dark' ? 'dark' : 'light',
    adBlockEnabled: savedPreferences.adBlockEnabled !== false,
    performanceMode: savedPreferences.performanceMode === 'balanced' ? 'balanced' : 'maximum',
    hardwareAcceleration: savedPreferences.hardwareAcceleration !== false,
    downloadDirectory: typeof savedPreferences.downloadDirectory === 'string' && savedPreferences.downloadDirectory
      ? savedPreferences.downloadDirectory
      : app.getPath('downloads'),
    askDownloadLocation: savedPreferences.askDownloadLocation === true
  };
  historyItems = readJson('history.json', []);
  browserSession = session.fromPartition(PARTITION);
  registerDownloads();
  Menu.setApplicationMenu(null);
  registerIpc();
  createWindow();
  void applyAdBlocker();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

